# Building PrimeFaces from source:
PrimeFaces uses maven as the build tool. There's a custom maven plugin to generate jsf artifacts.

Change to the maven-jsf-plugin-directory and do a maven install:
`
  cd maven-jsf-plugin
  mvn install
`

Next thing to do is to build PrimeFaces itself:
`
  cd primefaces_4_0
  mvn install
`

# Modified source locations for ueps:
primefaces_4_0/src/main/java-templates/org/primefaces/component/datatable/DataTableTemplate.java (Line 737)
primefaces_4_0/src/test/java/org/primefaces/json/JSONObjectTest.java (Line 36)
