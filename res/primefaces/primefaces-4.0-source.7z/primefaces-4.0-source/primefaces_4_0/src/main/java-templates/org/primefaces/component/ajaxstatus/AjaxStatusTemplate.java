
    public final static String START = "start";
    public final static String SUCCESS= "success";
    public final static String COMPLETE = "complete";
    public final static String ERROR = "error";
    public final static String DEFAULT = "default";
    public final static String CALLBACK_SIGNATURE = "function()";

	public final static String[] EVENTS = {
        START,SUCCESS,COMPLETE,ERROR
    };