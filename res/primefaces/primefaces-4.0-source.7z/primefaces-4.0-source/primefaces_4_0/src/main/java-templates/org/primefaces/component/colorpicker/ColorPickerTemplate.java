
    public static final String STYLE_CLASS = "ui-colorpicker";