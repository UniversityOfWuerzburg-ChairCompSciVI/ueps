
    public final static String CONTAINER_CLASS = "ui-galleria ui-widget ui-widget-content ui-corner-all";
    public final static String PANEL_WRAPPER_CLASS = "ui-galleria-panel-wrapper";
    public final static String PANEL_CLASS = "ui-galleria-panel ui-helper-hidden";
    public final static String PANEL_CONTENT_CLASS = "ui-galleria-panel-content";