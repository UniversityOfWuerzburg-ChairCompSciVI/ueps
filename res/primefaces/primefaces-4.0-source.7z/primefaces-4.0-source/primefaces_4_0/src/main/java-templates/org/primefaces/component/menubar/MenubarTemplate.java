
    public static final String CONTAINER_CLASS = "ui-menu ui-menubar ui-widget ui-widget-content ui-corner-all ui-helper-clearfix";