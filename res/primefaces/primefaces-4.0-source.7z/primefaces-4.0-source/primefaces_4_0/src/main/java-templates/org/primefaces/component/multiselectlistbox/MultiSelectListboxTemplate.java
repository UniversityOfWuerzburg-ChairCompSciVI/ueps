    public static String CONTAINER_CLASS = "ui-multiselectlistbox ui-widget ui-helper-clearfix";
    public static String LIST_CONTAINER_CLASS = "ui-multiselectlistbox-listcontainer ui-inputfield ui-widget-content ui-corner-all";
    public static String LIST_CLASS = "ui-multiselectlistbox-list";
    public static String ITEM_CLASS = "ui-multiselectlistbox-item";