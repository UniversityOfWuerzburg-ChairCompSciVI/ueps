  
  public final static String STYLE_CLASS = "ui-notificationbar ui-widget ui-widget-content";