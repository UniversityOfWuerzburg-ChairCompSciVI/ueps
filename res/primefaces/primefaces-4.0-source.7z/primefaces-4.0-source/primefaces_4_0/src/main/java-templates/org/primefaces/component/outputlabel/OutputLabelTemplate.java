
    public final static String STYLE_CLASS = "ui-outputlabel ui-widget";
    public final static String REQUIRED_FIELD_INDICATOR_CLASS = "ui-outputlabel-rfi";