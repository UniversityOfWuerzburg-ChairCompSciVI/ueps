    
    public final static String STYLE_CLASS = "ui-selectmanycheckbox ui-widget";