
    public static final String CONTAINER_CLASS = "ui-tabmenu ui-widget ui-widget-content ui-corner-all";
    public static final String NAVIGATOR_CLASS = "ui-tabmenu-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all";
    public static final String INACTIVE_TAB_HEADER_CLASS = "ui-tabmenuitem ui-state-default ui-corner-top";
    public static final String ACTIVE_TAB_HEADER_CLASS = "ui-tabmenuitem ui-state-default ui-state-active ui-corner-top";