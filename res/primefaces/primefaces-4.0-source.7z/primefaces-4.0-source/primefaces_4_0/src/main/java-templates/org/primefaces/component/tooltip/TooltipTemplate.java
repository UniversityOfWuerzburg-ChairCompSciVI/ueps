
    public static String CONTAINER_CLASS = "ui-tooltip ui-widget ui-widget-content ui-shadow ui-corner-all";