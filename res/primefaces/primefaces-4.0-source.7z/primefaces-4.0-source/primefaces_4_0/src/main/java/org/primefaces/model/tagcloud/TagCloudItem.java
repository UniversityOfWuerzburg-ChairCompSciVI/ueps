package org.primefaces.model.tagcloud;

public interface TagCloudItem {

    public String getLabel();

    public String getUrl();

    public int getStrength();
}
